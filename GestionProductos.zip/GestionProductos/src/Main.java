import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        GestorProductos gestor = new GestorProductos();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("1. Crear producto");
            System.out.println("2. Mostrar productos");
            System.out.println("3. Actualizar producto");
            System.out.println("4. Eliminar producto");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = Integer.parseInt(scanner.nextLine());
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Precio: ");
                    double precio = Double.parseDouble(scanner.nextLine());
                    gestor.agregarProducto(new Producto(id, nombre, precio));
                    break;
                case 2:
                    gestor.mostrarProductos();
                    break;
                case 3:
                    System.out.print("ID: ");
                    int idActualizar = Integer.parseInt(scanner.nextLine());
                    System.out.print("Nuevo precio: ");
                    double nuevoPrecio = Double.parseDouble(scanner.nextLine());
                    if (gestor.actualizarProducto(idActualizar, nuevoPrecio)) {
                        System.out.println("Producto actualizado");
                    } else {
                        System.out.println("Producto no encontrado");
                    }
                    break;
                case 4:
                    System.out.print("ID: ");
                    int idEliminar = Integer.parseInt(scanner.nextLine());
                    if (gestor.eliminarProducto(idEliminar)) {
                        System.out.println("Producto eliminado");
                    } else {
                        System.out.println("Producto no encontrado");
                    }
                    break;
            }
        } while (opcion != 5);
    }
}
